# MercuryMessaging
This app will allow you to schedule or send a reminder through various messaging apps as well as sms.
